// src/lib/ics.ts
import type { GoalEvent, Session } from "../types";

function esc(s: string) {
    return s.replace(/\\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;");
}

function dtstamp() {
    // UTC timestamp like 20260221T120000Z
    const d = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(
        d.getUTCMinutes()
    )}${pad(d.getUTCSeconds())}Z`;
}

function dateToICS(dateISO: string) {
    // all-day event YYYYMMDD
    return dateISO.replaceAll("-", "");
}

export function buildRaceICS(goal: GoalEvent) {
    const uid = `race-${goal.id}@mtb-tracker`;
    const dt = dateToICS(goal.startDate);

    return [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//MTB Comeback Tracker//EN",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        "BEGIN:VEVENT",
        `UID:${uid}`,
        `DTSTAMP:${dtstamp()}`,
        `DTSTART;VALUE=DATE:${dt}`,
        `SUMMARY:${esc(goal.name)}`,
        goal.location ? `LOCATION:${esc(goal.location)}` : "",
        goal.link ? `URL:${esc(goal.link)}` : "",
        goal.notes ? `DESCRIPTION:${esc(goal.notes)}` : "",
        "END:VEVENT",
        "END:VCALENDAR",
    ]
        .filter(Boolean)
        .join("\r\n");
}

export function buildSessionsICS(sessions: Session[], titlePrefix = "MTB") {
    const events = sessions
        .filter((s) => s.scheduledDate)
        .map((s) => {
            const uid = `sess-${s.id}@mtb-tracker`;
            const dt = dateToICS(s.scheduledDate!);
            const summary = `${titlePrefix}: ${s.type} (${s.minutes}m)`;
            const desc = `${s.description}${s.zone ? ` | ${s.zone}` : ""}${s.elevation ? ` | ${s.elevation}` : ""}`;

            return [
                "BEGIN:VEVENT",
                `UID:${uid}`,
                `DTSTAMP:${dtstamp()}`,
                `DTSTART;VALUE=DATE:${dt}`,
                `SUMMARY:${esc(summary)}`,
                `DESCRIPTION:${esc(desc)}`,
                "END:VEVENT",
            ].join("\r\n");
        });

    return [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//MTB Comeback Tracker//EN",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        ...events,
        "END:VCALENDAR",
    ].join("\r\n");
}

export function downloadICS(filename: string, contents: string) {
    const blob = new Blob([contents], { type: "text/calendar;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
}
