import type { StravaAuth, AppData } from '../types';

export interface StravaActivity {
    id: number;
    name: string;
    distance: number; // meters
    moving_time: number; // seconds
    elapsed_time: number; // seconds
    total_elevation_gain: number; // meters
    type: string;
    sport_type: string;
    start_date_local: string; // ISO 8601
    average_heartrate?: number;
    max_heartrate?: number;
    suffer_score?: number;
}

const STRAVA_API_BASE = 'https://www.strava.com/api/v3';
const STRAVA_OAUTH_URL = 'https://www.strava.com/oauth/token';

export async function refreshStravaToken(auth: StravaAuth): Promise<StravaAuth> {
    const response = await fetch(STRAVA_OAUTH_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            client_id: auth.clientId,
            client_secret: auth.clientSecret,
            grant_type: 'refresh_token',
            refresh_token: auth.refreshToken,
        }),
    });

    if (!response.ok) {
        throw new Error('Failed to refresh Strava token');
    }

    const data = await response.json();
    return {
        clientId: auth.clientId,
        clientSecret: auth.clientSecret,
        refreshToken: data.refresh_token,
        accessToken: data.access_token,
        expiresAt: data.expires_at, // Epoch seconds
    };
}

export async function getValidStravaToken(auth: StravaAuth, onTokenRefreshed: (newAuth: StravaAuth) => void): Promise<string> {
    // If we have an access token and it's not expired (add a 5 min buffer)
    const nowEpoch = Math.floor(Date.now() / 1000);
    if (auth.accessToken && auth.expiresAt && auth.expiresAt > nowEpoch + 300) {
        return auth.accessToken;
    }

    // Otherwise, we need to refresh
    try {
        const newAuth = await refreshStravaToken(auth);
        onTokenRefreshed(newAuth);
        return newAuth.accessToken!;
    } catch (e) {
        console.error('Strava Token Refresh Error', e);
        throw e;
    }
}

export async function fetchRecentActivities(accessToken: string, afterEpochSeconds?: number): Promise<StravaActivity[]> {
    let url = `${STRAVA_API_BASE}/athlete/activities?per_page=30`;
    if (afterEpochSeconds) {
        url += `&after=${afterEpochSeconds}`;
    }

    const response = await fetch(url, {
        headers: {
            Authorization: `Bearer ${accessToken}`,
        },
    });

    if (!response.ok) {
        throw new Error(`Failed to fetch activities: ${response.statusText}`);
    }

    return await response.json();
}

/**
 * Syncs recent Strava activities into AppData by updating matching Sessions and Metrics.
 */
export async function syncStravaToAppData(appData: AppData, auth: StravaAuth, onTokenRefreshed: (newAuth: StravaAuth) => void): Promise<AppData> {
    const accessToken = await getValidStravaToken(auth, onTokenRefreshed);

    // Fetch last 14 days of activities
    const afterDate = Math.floor(Date.now() / 1000) - (14 * 24 * 60 * 60);
    const activities = await fetchRecentActivities(accessToken, afterDate);

    let updatedSessions = [...appData.sessions];
    let updatedMetrics = [...appData.metrics];

    for (const activity of activities) {
        // Only care about rides
        if (activity.type !== 'Ride' && activity.type !== 'VirtualRide' && activity.sport_type !== 'MountainBikeRide' && activity.sport_type !== 'GravelRide') {
            continue;
        }

        const dateIso = activity.start_date_local.split('T')[0];
        const minutes = Math.round(activity.moving_time / 60);
        const distanceKm = Number((activity.distance / 1000).toFixed(1));

        // 1. Update Session if one exists for this date
        const sessionIndex = updatedSessions.findIndex(s => s.scheduledDate === dateIso);
        if (sessionIndex >= 0) {
            updatedSessions[sessionIndex] = {
                ...updatedSessions[sessionIndex],
                completed: true,
                completedAt: activity.start_date_local,
                // optionally update minutes here, but we'll leave scheduled minutes and maybe add actual.
                // for now just mark it completed.
            };
        } else {
            // Unscheduled ride? Could create a fake session, but let's just log it in metrics.
        }

        // 2. Update Metric entry
        const metricIndex = updatedMetrics.findIndex(m => m.date === dateIso);
        if (metricIndex >= 0) {
            updatedMetrics[metricIndex] = {
                ...updatedMetrics[metricIndex],
                rideMinutes: (updatedMetrics[metricIndex].rideMinutes || 0) + minutes,
                longRideKm: distanceKm > 30 ? distanceKm : updatedMetrics[metricIndex].longRideKm,
                notes: updatedMetrics[metricIndex].notes ? `${updatedMetrics[metricIndex].notes}\nStrava: ${activity.name}` : `Strava: ${activity.name}`
            };
        } else {
            updatedMetrics.push({
                date: dateIso,
                rideMinutes: minutes,
                longRideKm: distanceKm > 30 ? distanceKm : undefined,
                notes: `Strava: ${activity.name}`
            });
        }
    }

    return {
        ...appData,
        sessions: updatedSessions,
        metrics: updatedMetrics
    };
}
