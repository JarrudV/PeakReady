// src/lib/anchorPlan.ts
import type { Session, GoalEvent } from "../types";
import { parseISODate, subWeeks, nextDow, addDays, toISODate } from "../lib/dates";

const DOW = {
    Tue: 2,
    Thu: 4,
    Sat: 6,
    Sun: 0,
} as const;

export function computePlanStart(goalStartDateISO: string) {
    const raceDate = parseISODate(goalStartDateISO);
    // Plan starts 12 weeks before race week (start on a Monday-ish anchor)
    // We'll anchor week 1 to the week containing this start date.
    // Use raceDate - 12 weeks, then roll to Monday (or keep as is).
    const raw = subWeeks(raceDate, 12);
    // roll to Monday (1)
    const monday = nextDow(raw, 1);
    return monday;
}

export function anchorSessionsToGoal(sessions: Session[], goal: GoalEvent): Session[] {
    const planStart = computePlanStart(goal.startDate);

    return sessions.map((s) => {
        const weekIndex = Math.max(0, s.week - 1);
        // week start = planStart + (weekIndex * 7 days)
        const weekStart = addDays(planStart, weekIndex * 7);

        const dow = DOW[s.day];
        // scheduled date = first occurrence of that DOW on/after weekStart
        const date = nextDow(weekStart, dow);

        return {
            ...s,
            scheduledDate: toISODate(date),
        };
    });
}
