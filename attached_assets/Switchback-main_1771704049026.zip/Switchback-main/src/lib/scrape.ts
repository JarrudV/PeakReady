// src/lib/scrape.ts
export type ScrapeResult = {
    name?: string;
    dateISO?: string;
    location?: string;
    distanceKm?: number;
    notes?: string;
};

function findDateISO(text: string): string | undefined {
    // Very basic: look for YYYY-MM-DD first
    const iso = text.match(/\b(20\d{2})-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])\b/);
    if (iso) return iso[0];

    // Add more formats if you want later (e.g. "17 May 2026")
    return undefined;
}

function findDistanceKm(text: string): number | undefined {
    const m = text.match(/(\d{2,3})\s?(km|KM|Km)\b/);
    if (!m) return;
    const n = Number(m[1]);
    return Number.isFinite(n) ? n : undefined;
}

export async function tryScrapeRace(url: string): Promise<ScrapeResult> {
    const res = await fetch(url);
    const html = await res.text();

    // quick and dirty title
    const titleMatch = html.match(/<title[^>]*>(.*?)<\/title>/i);
    const name = titleMatch ? titleMatch[1].trim() : undefined;

    // strip tags for easier scanning
    const text = html
        .replace(/<script[\s\S]*?<\/script>/gi, " ")
        .replace(/<style[\s\S]*?<\/style>/gi, " ")
        .replace(/<[^>]+>/g, " ")
        .replace(/\s+/g, " ")
        .trim();

    return {
        name,
        dateISO: findDateISO(text),
        distanceKm: findDistanceKm(text),
    };
}
