import type { Session, SessionType, ServiceItem } from '../types';

const generateWeek = (week: number, template: { day: Session['day']; type: SessionType; duration: number; desc: string; zone?: string; elevation?: string; strength?: boolean }[]): Session[] => {
    return template.map((t, i) => ({
        id: `w${week}-d${i + 1}-${Date.now()}`,
        week,
        day: t.day,
        type: t.type,
        description: t.desc,
        minutes: t.duration,
        ...(t.zone && { zone: t.zone }),
        ...(t.elevation && { elevation: t.elevation }),
        strength: t.strength === true,
        completed: false
    }));
};

export const defaultServiceItems: ServiceItem[] = [
    { id: 's1', item: 'Tyres', status: 'Planned' },
    { id: 's2', item: 'Chain', status: 'Planned' },
    { id: 's3', item: 'Brake pads', status: 'Planned' },
    { id: 's4', item: 'Fork service', status: 'Planned' },
    { id: 's5', item: 'Wheel truing', status: 'Planned' },
    { id: 's6', item: 'Bottom bracket', status: 'Planned' },
    { id: 's7', item: 'Tubeless refresh', status: 'Planned' },
];

export const generateTrainingPlan = (): Session[] => {
    let sessions: Session[] = [];

    // Weeks 1-4: Base aerobic focus (Z2)
    for (let w = 1; w <= 4; w++) {
        sessions = sessions.concat(generateWeek(w, [
            { day: 'Tue', type: 'Ride', duration: 60, desc: 'Endurance Base', zone: 'Z2' },
            { day: 'Thu', type: 'Ride', duration: 60, desc: 'Endurance Base', zone: 'Z2' },
            { day: 'Sat', type: 'Strength', duration: 45, desc: 'Core & Mobility', strength: true },
            { day: 'Sun', type: 'Long Ride', duration: 90 + (w * 15), desc: 'Long Aerobic Ride', zone: 'Z2', elevation: '300m' },
        ]));
    }

    // Weeks 5-8: Climbing intervals
    for (let w = 5; w <= 8; w++) {
        sessions = sessions.concat(generateWeek(w, [
            { day: 'Tue', type: 'Ride', duration: 75, desc: 'Hill Repeats (3x5min)', zone: 'Z4', elevation: '500m' },
            { day: 'Thu', type: 'Ride', duration: 60, desc: 'Tempo Ride', zone: 'Z3' },
            { day: 'Sat', type: 'Strength', duration: 30, desc: 'Lower Body Strength', strength: true },
            { day: 'Sun', type: 'Long Ride', duration: 120 + ((w - 4) * 20), desc: 'Hilly Endurance', zone: 'Z2', elevation: '1000m' },
        ]));
    }

    // Weeks 9-11: Peak endurance
    for (let w = 9; w <= 11; w++) {
        sessions = sessions.concat(generateWeek(w, [
            { day: 'Tue', type: 'Ride', duration: 90, desc: 'Threshold Intervals (4x8min)', zone: 'Z4', elevation: '400m' },
            { day: 'Thu', type: 'Ride', duration: 75, desc: 'Sweet Spot', zone: 'Z3' },
            { day: 'Sat', type: 'Strength', duration: 30, desc: 'Maintenance & Core', strength: true },
            { day: 'Sun', type: 'Long Ride', duration: 180 + ((w - 9) * 30), desc: 'Peak Long Ride (Race Sim)', zone: 'Z2-Z3', elevation: '1500m' }, // up to ~4 hours (240m)
        ]));
    }

    // Week 12: Taper + Race
    sessions = sessions.concat(generateWeek(12, [
        { day: 'Tue', type: 'Ride', duration: 45, desc: 'Active Recovery', zone: 'Z1' },
        { day: 'Thu', type: 'Ride', duration: 45, desc: 'Openers (Short Sprints)', zone: 'Z3-Z5' },
        { day: 'Sat', type: 'Rest', duration: 0, desc: 'Rest & Prep' },
        { day: 'Sun', type: 'Long Ride', duration: 300, desc: '86km RACE DAY', zone: 'Race', elevation: 'TBD' },
    ]));

    return sessions;
};
