import type { AppData, Session, Metric, ServiceItem, GoalEvent, StravaAuth } from '../types';
import { generateTrainingPlan, defaultServiceItems } from './seed';
import { anchorSessionsToGoal } from './anchorPlan';

export function load<T>(key: string, fallback: T): T {
    try {
        const raw = localStorage.getItem(key);
        return raw ? (JSON.parse(raw) as T) : fallback;
    } catch {
        return fallback;
    }
}

export function save<T>(key: string, value: T) {
    localStorage.setItem(key, JSON.stringify(value));
}

export const keys = {
    sessions: "mtb.sessions.v1",
    metrics: "mtb.metrics.v1",
    service: "mtb.service.v1",
    goal: "mtb.goal.v1",
    activeWeek: "mtb.activeWeek.v1",
    strava: "mtb.strava.v1",
} as const;

export const loadFromStorage = (): AppData => {
    const goal = load<GoalEvent | undefined>(keys.goal, {
        id: 'race-86km',
        name: '86km Comeback Race',
        startDate: '2026-05-17', // Approx 12 weeks from Feb 21
        distanceKm: 86,
        createdAt: new Date().toISOString()
    });

    const rawSessions = load<Session[]>(keys.sessions, []);

    // Initialize seeded data if completely empty
    const isFirstLoad = rawSessions.length === 0;
    let sessions = rawSessions;

    if (isFirstLoad && goal) {
        sessions = anchorSessionsToGoal(generateTrainingPlan(), goal);
    }

    return {
        sessions,
        metrics: load<Metric[]>(keys.metrics, []),
        serviceItems: load<ServiceItem[]>(keys.service, defaultServiceItems),
        activeWeek: load<number>(keys.activeWeek, 1),
        goal,
        strava: load<StravaAuth | undefined>(keys.strava, undefined)
    };
};

export const saveToStorage = (data: AppData): void => {
    save(keys.sessions, data.sessions);
    save(keys.metrics, data.metrics);
    save(keys.service, data.serviceItems);
    save(keys.activeWeek, data.activeWeek);
    if (data.goal) save(keys.goal, data.goal);
    if (data.strava) save(keys.strava, data.strava);
};

// Handlers for specific updates
export const updateSession = (data: AppData, updatedSession: Session): AppData => {
    return {
        ...data,
        sessions: data.sessions.map(s => s.id === updatedSession.id ? updatedSession : s)
    };
};

export const addMetricEntry = (data: AppData, entry: Metric): AppData => {
    return {
        ...data,
        metrics: [...data.metrics, entry]
    };
};

export const updateServiceItem = (data: AppData, updatedItem: ServiceItem): AppData => {
    return {
        ...data,
        serviceItems: data.serviceItems.map(s => s.id === updatedItem.id ? updatedItem : s)
    };
};

export const setActiveWeek = (data: AppData, week: number): AppData => {
    return {
        ...data,
        activeWeek: week
    };
};
