import { useState, useEffect } from 'react';
import { Home, CalendarDays, Activity, Wrench, MountainSnow, Settings as SettingsIcon } from 'lucide-react';
import { Dashboard } from './features/dashboard/Dashboard';
import { TrainingPlan } from './features/plan/TrainingPlan';
import { Metrics } from './features/metrics/Metrics';
import { ServiceTracker } from './features/service/ServiceTracker';
import { EventTracker } from './features/events/EventTracker';
import { Settings } from './features/settings/Settings';
import type { AppData } from './types';
import { loadFromStorage, saveToStorage } from './lib/storage';
import { cn } from './lib/utils';

type Tab = 'dashboard' | 'plan' | 'metrics' | 'service' | 'events';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [appData, setAppData] = useState<AppData | null>(null);

  // Initialize data on mount
  useEffect(() => {
    setAppData(loadFromStorage());
  }, []);

  // Save data whenever it changes
  useEffect(() => {
    if (appData) {
      saveToStorage(appData);
    }
  }, [appData]);

  if (!appData) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-brand-bg text-brand-text font-sans pb-20">
      {/* Header */}
      <header className="glass-panel rounded-none border-x-0 border-t-0 p-4 sticky top-0 z-50 shadow-lg shadow-black/20 flex items-center justify-between">
        <div className="w-8"></div> {/* Spacer for centering */}
        <div className="flex items-center gap-2">
          <img src="/logo.svg" alt="Switchback Logo" className="w-8 h-8" />
          <h1 className="text-xl font-bold tracking-tight">Switch<span className="text-gradient-primary">back</span></h1>
        </div>
        <button
          onClick={() => setIsSettingsOpen(true)}
          className="w-8 h-8 flex items-center justify-center rounded-full bg-brand-bg/50 border border-brand-border hover:bg-brand-panel transition-colors text-brand-muted hover:text-brand-text"
        >
          <SettingsIcon size={18} />
        </button>
      </header>

      {/* Main Content Area */}
      <main className="max-w-md mx-auto w-full pb-4 pt-4 relative">
        {isSettingsOpen ? (
          <div className="absolute inset-0 bg-brand-bg z-40 min-h-[calc(100vh-80px)]">
            <Settings appData={appData} setAppData={setAppData} onClose={() => setIsSettingsOpen(false)} />
          </div>
        ) : (
          <>
            {activeTab === 'dashboard' && <Dashboard appData={appData} setAppData={setAppData} />}
            {activeTab === 'plan' && <TrainingPlan appData={appData} setAppData={setAppData} />}
            {activeTab === 'metrics' && <Metrics appData={appData} setAppData={setAppData} />}
            {activeTab === 'service' && <ServiceTracker appData={appData} setAppData={setAppData} />}
            {activeTab === 'events' && <EventTracker appData={appData} setAppData={setAppData} />}
          </>
        )}
      </main>

      {/* Bottom Navigation */}
      {!isSettingsOpen && (
        <nav className="fixed bottom-0 w-full glass-panel rounded-none border-x-0 border-b-0 px-4 py-3 flex justify-between items-center z-30 pb-safe shadow-[0_-8px_30px_rgba(0,0,0,0.5)]">
          <NavItem
            icon={<Home size={22} />}
            label="Dash"
            isActive={activeTab === 'dashboard'}
            onClick={() => setActiveTab('dashboard')}
          />
          <NavItem
            icon={<CalendarDays size={22} />}
            label="Plan"
            isActive={activeTab === 'plan'}
            onClick={() => setActiveTab('plan')}
          />
          <NavItem
            icon={<MountainSnow size={24} />}
            label="Events"
            isActive={activeTab === 'events'}
            isHighlight={true}
            onClick={() => setActiveTab('events')}
          />
          <NavItem
            icon={<Activity size={22} />}
            label="Metrics"
            isActive={activeTab === 'metrics'}
            onClick={() => setActiveTab('metrics')}
          />
          <NavItem
            icon={<Wrench size={22} />}
            label="Bike"
            isActive={activeTab === 'service'}
            onClick={() => setActiveTab('service')}
          />
        </nav>
      )}
    </div>
  );
}

function NavItem({ icon, label, isActive, isHighlight, onClick }: { icon: React.ReactNode; label: string; isActive: boolean; isHighlight?: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex flex-col items-center justify-center w-14 transition-all duration-300 relative",
        isActive && !isHighlight ? "text-brand-primary font-medium drop-shadow-[0_0_8px_rgba(65,209,255,0.8)]" : "text-brand-muted hover:text-brand-text",
        isHighlight && "text-brand-text"
      )}
    >
      {isHighlight && (
        <div className="absolute inset-0 bg-gradient-primary blur-lg opacity-20 -z-10 rounded-full scale-150"></div>
      )}
      <div className={cn(
        "mb-1 flex items-center justify-center",
        isActive && !isHighlight && "scale-110",
        isHighlight && "p-3 rounded-full bg-gradient-primary shadow-[0_0_15px_rgba(189,52,254,0.5)] -mt-6 ring-4 ring-brand-bg",
        isActive && isHighlight && "scale-110 shadow-[0_0_25px_rgba(65,209,255,0.8)] ring-brand-panel"
      )}>
        {icon}
      </div>
      <span className={cn("text-[10px] uppercase tracking-wider", isHighlight && "mt-1")}>{label}</span>
    </button>
  );
}

export default App;
