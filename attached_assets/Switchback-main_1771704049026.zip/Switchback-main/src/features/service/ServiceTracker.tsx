import { useState } from 'react';
import type { AppData, ServiceItem } from '../../types';
import { updateServiceItem } from '../../lib/storage';
import { Plus, X, Settings, CheckCircle2, Circle, Clock, Tag } from 'lucide-react';
import { cn } from '../../lib/utils';

interface Props {
    appData: AppData;
    setAppData: (data: AppData) => void;
}

export function ServiceTracker({ appData, setAppData }: Props) {
    const [isAdding, setIsAdding] = useState(false);
    const { serviceItems } = appData;

    const handleUpdateStatus = (item: ServiceItem, newStatus: ServiceItem['status']) => {
        setAppData(updateServiceItem(appData, {
            ...item,
            status: newStatus,
            date: newStatus === 'Done' ? new Date().toISOString() : item.date
        }));
    };

    const handleAddItem = (newItem: ServiceItem) => {
        setAppData({
            ...appData,
            serviceItems: [...appData.serviceItems, newItem]
        });
        setIsAdding(false);
    };

    // Sort: In Progress first, Planned second, Done last
    const sortedItems = [...serviceItems].sort((a, b) => {
        const statusWeight = { 'In Progress': 0, 'Planned': 1, 'Done': 2 };
        if (statusWeight[a.status] !== statusWeight[b.status]) {
            return statusWeight[a.status] - statusWeight[b.status];
        }
        return 0; // Maintain insertion order if same status
    });

    return (
        <div className="p-4 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold">Bike Maintenance</h2>
                <button
                    onClick={() => setIsAdding(!isAdding)}
                    className={cn(
                        "p-2 rounded-full transition-all shadow-lg",
                        isAdding
                            ? "bg-brand-panel-2 text-brand-text hover:bg-brand-border"
                            : "bg-gradient-primary text-brand-bg hover:opacity-90 shadow-[0_0_15px_rgba(65,209,255,0.4)]"
                    )}
                >
                    {isAdding ? <X size={20} /> : <Plus size={20} />}
                </button>
            </div>

            {isAdding && <AddServiceForm onAdd={handleAddItem} onCancel={() => setIsAdding(false)} />}

            {!isAdding && (
                <div className="space-y-4">
                    <div className="flex justify-between text-xs font-bold text-brand-muted uppercase tracking-widest px-2">
                        <span>Tasks</span>
                        <span>Status</span>
                    </div>

                    <div className="flex flex-col gap-3">
                        {sortedItems.map(item => (
                            <ServiceItemCard
                                key={item.id}
                                item={item}
                                onStatusChange={(status) => handleUpdateStatus(item, status)}
                            />
                        ))}

                        {sortedItems.length === 0 && (
                            <p className="text-brand-muted text-[10px] uppercase font-bold tracking-widest text-center py-8 glass-panel border border-brand-border/50">
                                Bike is in perfect condition!
                            </p>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

function ServiceItemCard({ item, onStatusChange }: { item: ServiceItem, onStatusChange: (status: ServiceItem['status']) => void }) {
    const isDone = item.status === 'Done';

    return (
        <div className={cn(
            "p-4 rounded-xl border transition-all duration-300 relative overflow-hidden",
            isDone ? "bg-brand-bg opacity-70 border-brand-border" :
                item.status === 'In Progress' ? "glass-panel border-brand-primary/50 shadow-[0_0_15px_rgba(65,209,255,0.1)]" :
                    "glass-panel border-brand-border/50 hover:border-brand-primary/30"
        )}>
            {item.status === 'In Progress' && (
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-primary opacity-10 blur-2xl rounded-full pointer-events-none"></div>
            )}
            <div className="flex justify-between items-start relative z-10">
                <div className="flex-1">
                    <h3 className={cn("text-lg font-bold leading-tight mb-1", isDone && "line-through text-brand-muted")}>
                        {item.item}
                    </h3>
                    {(item.shop || item.cost != null) && (
                        <div className="flex gap-3 text-[10px] uppercase font-bold tracking-widest text-brand-muted mb-2">
                            {item.shop && <span className="flex items-center"><Settings size={12} className="mr-1 text-brand-primary" /> {item.shop}</span>}
                            {item.cost != null && <span className="flex items-center"><Tag size={12} className="mr-1 text-brand-secondary" /> ${item.cost}</span>}
                        </div>
                    )}
                    {item.notes && <p className="text-sm text-brand-muted italic">"{item.notes}"</p>}
                </div>

                {/* Status toggles */}
                <div className="flex flex-col gap-2 ml-4">
                    <button
                        onClick={() => onStatusChange(isDone ? 'Planned' : 'Done')}
                        className={cn(
                            "flex items-center justify-center p-2 rounded-full transition-all",
                            isDone ? "bg-brand-success/20 text-brand-success" : "bg-brand-panel-2 text-brand-muted hover:bg-brand-border hover:text-brand-text"
                        )}
                    >
                        {isDone ? <CheckCircle2 size={20} /> : <Circle size={20} />}
                    </button>
                    {!isDone && (
                        <button
                            onClick={() => onStatusChange(item.status === 'In Progress' ? 'Planned' : 'In Progress')}
                            className={cn(
                                "flex items-center justify-center p-2 rounded-full transition-all",
                                item.status === 'In Progress' ? "bg-brand-primary/20 text-brand-primary" : "bg-brand-panel-2 text-brand-muted hover:bg-brand-border hover:text-brand-text"
                            )}
                        >
                            <Clock size={20} />
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
}

function AddServiceForm({ onAdd, onCancel }: { onAdd: (item: ServiceItem) => void, onCancel: () => void }) {
    const [item, setItem] = useState('');
    const [shop, setShop] = useState('');
    const [cost, setCost] = useState('');
    const [notes, setNotes] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!item.trim()) return;

        onAdd({
            id: `svc-${Date.now()}`,
            item: item.trim(),
            shop: shop.trim() || undefined,
            cost: cost ? parseFloat(cost) : undefined,
            notes: notes.trim() || undefined,
            status: 'Planned'
        });
    };

    return (
        <form onSubmit={handleSubmit} className="glass-panel p-5 border-brand-warning/30 shadow-[0_0_20px_rgba(255,168,0,0.1)] mb-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-secondary opacity-15 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none"></div>

            <h3 className="text-lg font-bold mb-4 relative z-10">Add Maintenance Task</h3>

            <div className="space-y-4 relative z-10">
                <div>
                    <label className="text-xs text-brand-muted font-medium block mb-1">Task Name</label>
                    <input
                        type="text"
                        required
                        value={item}
                        onChange={e => setItem(e.target.value)}
                        className="w-full bg-brand-bg text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm focus:ring-1 focus:ring-brand-primary outline-none"
                        placeholder="e.g. Replace seal kit"
                    />
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="text-xs text-brand-muted font-medium block mb-1">Shop / Mechanic</label>
                        <input
                            type="text"
                            value={shop}
                            onChange={e => setShop(e.target.value)}
                            className="w-full bg-brand-bg text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm focus:ring-1 focus:ring-brand-primary outline-none"
                            placeholder="e.g. LBS"
                        />
                    </div>
                    <div>
                        <label className="text-xs text-brand-muted font-medium block mb-1">Estimated Cost ($)</label>
                        <input
                            type="number"
                            step="1"
                            value={cost}
                            onChange={e => setCost(e.target.value)}
                            className="w-full bg-brand-bg text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm focus:ring-1 focus:ring-brand-primary outline-none"
                        />
                    </div>
                </div>

                <div>
                    <label className="text-xs text-brand-muted font-medium block mb-1">Notes</label>
                    <textarea
                        value={notes}
                        onChange={e => setNotes(e.target.value)}
                        className="w-full bg-brand-bg text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm min-h-[60px] resize-none focus:ring-1 focus:ring-brand-primary outline-none"
                        placeholder="Parts are ordered..."
                    />
                </div>

                <div className="flex gap-3 pt-3 text-[10px] tracking-widest uppercase font-bold">
                    <button
                        type="button"
                        onClick={onCancel}
                        className="flex-1 py-3 bg-brand-bg border border-brand-border/60 hover:bg-brand-panel text-brand-text rounded-lg transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        type="submit"
                        className="flex-1 py-3 bg-gradient-secondary border border-brand-warning/50 text-brand-bg rounded-lg transition-all shadow-[0_0_15px_rgba(255,168,0,0.4)] hover:shadow-[0_0_20px_rgba(255,168,0,0.6)] flex items-center justify-center gap-2"
                    >
                        Add Task
                    </button>
                </div>
            </div>
        </form>
    );
}
