import { useState } from 'react';
import type { AppData } from '../../types';
import { X, Save, Key, AlertTriangle, CheckCircle } from 'lucide-react';

interface Props {
    appData: AppData;
    setAppData: (data: AppData) => void;
    onClose: () => void;
}

export function Settings({ appData, setAppData, onClose }: Props) {
    const [clientId, setClientId] = useState(appData.strava?.clientId || '');
    const [clientSecret, setClientSecret] = useState(appData.strava?.clientSecret || '');
    const [refreshToken, setRefreshToken] = useState(appData.strava?.refreshToken || '');
    const [saved, setSaved] = useState(false);

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();

        // If keeping empty strings, just clear it
        if (!clientId.trim() && !clientSecret.trim() && !refreshToken.trim()) {
            setAppData({
                ...appData,
                strava: undefined
            });
        } else {
            setAppData({
                ...appData,
                strava: {
                    clientId: clientId.trim(),
                    clientSecret: clientSecret.trim(),
                    refreshToken: refreshToken.trim(),
                    // preserve access token if we haven't changed the credentials
                    accessToken: (appData.strava?.clientId === clientId.trim()) ? appData.strava?.accessToken : undefined,
                    expiresAt: (appData.strava?.clientId === clientId.trim()) ? appData.strava?.expiresAt : undefined,
                }
            });
        }

        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
    };

    return (
        <div className="p-4 space-y-6 animate-in slide-in-from-right-8 duration-300 relative z-40 bg-brand-bg min-h-[calc(100vh-80px)]">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold flex items-center gap-2">
                    <Key className="text-brand-secondary" /> Settings
                </h2>
                <button
                    onClick={onClose}
                    className="p-2 rounded-full glass-panel hover:bg-brand-panel-2 transition-all shadow-lg"
                >
                    <X size={20} />
                </button>
            </div>

            <div className="glass-panel p-5 relative overflow-hidden shadow-[0_0_20px_rgba(255,168,0,0.1)]">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-secondary opacity-10 blur-3xl -mr-10 -mt-10 rounded-full pointer-events-none"></div>

                <h3 className="text-lg font-bold mb-2 flex flex-col">
                    <span className="text-brand-secondary">Strava Integration</span>
                </h3>

                <p className="text-xs text-brand-muted mb-6 leading-relaxed">
                    Connect your training data safely offline. Generate your API credentials on the
                    <a href="https://www.strava.com/settings/api" target="_blank" rel="noreferrer" className="text-brand-primary hover:underline mx-1">
                        Strava API Settings
                    </a>
                    page. Since this is an offline PWA, your secret is only stored directly on your device.
                </p>

                <form onSubmit={handleSave} className="space-y-4">
                    <div>
                        <label className="text-[10px] text-brand-muted uppercase font-bold tracking-widest block mb-1">Client ID</label>
                        <input
                            type="text"
                            value={clientId}
                            onChange={(e) => setClientId(e.target.value)}
                            className="w-full bg-brand-bg/50 text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm focus:ring-1 focus:ring-brand-primary outline-none focus:border-brand-primary/50 transition-colors"
                            placeholder="e.g. 12345"
                        />
                    </div>

                    <div>
                        <label className="text-[10px] text-brand-muted uppercase font-bold tracking-widest block mb-1 flex items-center gap-1">
                            Client Secret <AlertTriangle size={10} className="text-brand-warning" />
                        </label>
                        <input
                            type="password"
                            value={clientSecret}
                            onChange={(e) => setClientSecret(e.target.value)}
                            className="w-full bg-brand-bg/50 text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm focus:ring-1 focus:ring-brand-primary outline-none focus:border-brand-primary/50 transition-colors font-mono"
                            placeholder="Never share this"
                        />
                    </div>

                    <div>
                        <label className="text-[10px] text-brand-muted uppercase font-bold tracking-widest block mb-1">Initial Refresh Token</label>
                        <input
                            type="password"
                            value={refreshToken}
                            onChange={(e) => setRefreshToken(e.target.value)}
                            className="w-full bg-brand-bg/50 text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm focus:ring-1 focus:ring-brand-primary outline-none focus:border-brand-primary/50 transition-colors font-mono"
                            placeholder="Paste refresh token"
                        />
                    </div>

                    <div className="pt-2">
                        <button
                            type="submit"
                            className="w-full py-3 bg-gradient-secondary border border-brand-warning/50 text-brand-bg font-bold tracking-wide rounded-lg transition-all shadow-[0_0_15px_rgba(255,168,0,0.4)] hover:shadow-[0_0_20px_rgba(255,168,0,0.6)] flex items-center justify-center gap-2"
                        >
                            {saved ? <><CheckCircle size={18} /> Saved</> : <><Save size={18} /> Save Credentials</>}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
