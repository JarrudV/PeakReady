import { useState } from 'react';
import type { AppData } from '../../types';
import { syncStravaToAppData } from '../../lib/strava';
import {
    weekStats,
    totalCompletedSessions,
    latestMetric,
    planStatus,
    calculateReadinessScore
} from '../../lib/stats';
import { setActiveWeek } from '../../lib/storage';
import { ChevronDown, TrendingDown, TrendingUp, Minus, RefreshCw, AlertCircle, Zap, Activity as ActivityIcon } from 'lucide-react';
import { cn } from '../../lib/utils';

interface Props {
    appData: AppData;
    setAppData: (data: AppData) => void;
}

export function Dashboard({ appData, setAppData }: Props) {
    const { activeWeek, sessions, metrics, strava, goal } = appData;
    const [isSyncing, setIsSyncing] = useState(false);
    const [syncError, setSyncError] = useState<string | null>(null);

    const currentWeekStats = weekStats(sessions, activeWeek);
    const targetHours = currentWeekStats.targetMinutes / 60;
    const completedHours = currentWeekStats.completedMinutes / 60;
    const completionPct = currentWeekStats.completionPct;

    const totalSessions = totalCompletedSessions(sessions);

    // New Gamification Stats
    const statusInfo = planStatus(sessions, goal);
    const readinessScore = calculateReadinessScore(sessions, metrics, activeWeek);

    // Get latest metrics
    const currentWeight = latestMetric(metrics, 'weightKg');

    // Calculate weight delta (latest vs earliest recorded if there's more than 1)
    let weightDelta: number | null = null;
    const weightEntries = metrics.filter(m => m.weightKg !== undefined).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    if (weightEntries.length > 1) {
        weightDelta = weightEntries[weightEntries.length - 1].weightKg! - weightEntries[0].weightKg!;
    }

    const latestFatigue = latestMetric(metrics, 'fatigue');

    const handleWeekChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setAppData(setActiveWeek(appData, parseInt(e.target.value, 10)));
    };

    const handleSync = async () => {
        if (!strava) {
            setSyncError("Strava not configured. Please add your credentials in Settings.");
            setTimeout(() => setSyncError(null), 4000);
            return;
        }

        try {
            setIsSyncing(true);
            setSyncError(null);
            const updatedData = await syncStravaToAppData(appData, strava, (newAuth) => {
                // Background update if token refreshes
                setAppData({ ...appData, strava: newAuth });
            });
            setAppData(updatedData);
        } catch (e: any) {
            console.error(e);
            setSyncError(e.message || "Failed to sync with Strava.");
            setTimeout(() => setSyncError(null), 4000);
        } finally {
            setIsSyncing(false);
        }
    };

    return (
        <div className="p-4 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Header and Sync/Week Selector */}
            <div className="flex justify-between items-center bg-brand-bg relative z-10">
                <div className="flex items-center gap-3">
                    <h2 className="text-2xl font-bold">Dashboard</h2>
                    <button
                        onClick={handleSync}
                        disabled={isSyncing}
                        className={cn(
                            "p-2 rounded-full glass-panel hover:bg-brand-panel-2 transition-all shadow-[0_0_10px_rgba(255,168,0,0.1)]",
                            isSyncing ? "opacity-50 cursor-not-allowed" : "text-brand-secondary hover:text-white"
                        )}
                        title="Sync Strava"
                    >
                        <RefreshCw size={16} className={cn(isSyncing && "animate-spin")} />
                    </button>
                </div>
                <div className="relative">
                    <select
                        value={activeWeek}
                        onChange={handleWeekChange}
                        className="appearance-none glass-panel py-2 pl-4 pr-10 text-brand-text font-bold uppercase tracking-widest text-xs focus:outline-none focus:ring-1 focus:ring-brand-primary cursor-pointer shadow-[0_0_10px_rgba(65,209,255,0.1)]"
                    >
                        {Array.from({ length: 12 }, (_, i) => i + 1).map(w => (
                            <option className="bg-brand-bg text-brand-text" key={w} value={w}>Week {w}</option>
                        ))}
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-brand-primary pointer-events-none" size={16} />
                </div>
            </div>

            {syncError && (
                <div className="glass-panel p-3 border-brand-danger/30 text-brand-danger text-xs font-medium flex items-center gap-2 animate-in slide-in-from-top-2">
                    <AlertCircle size={14} />
                    {syncError}
                </div>
            )}

            {/* Primary Goal Card */}
            <div className="glass-panel p-6 shadow-[0_0_20px_rgba(189,52,254,0.15)] relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-primary opacity-20 blur-3xl -mr-10 -mt-10 rounded-full"></div>

                <h3 className="text-brand-muted text-[10px] uppercase tracking-widest font-bold mb-1 relative z-10">Weekly Progress</h3>

                <div className="flex items-end gap-2 mb-4 relative z-10">
                    <span className="text-5xl font-black font-mono text-white text-gradient-primary">{completedHours.toFixed(1)}</span>
                    <span className="text-brand-muted font-bold text-sm mb-1 uppercase tracking-widest">/ {targetHours.toFixed(1)} hrs</span>
                </div>

                {/* Progress Bar */}
                <div className="w-full bg-brand-bg/50 rounded-full h-3 mb-2 relative overflow-hidden z-10 border border-brand-border/50">
                    <div
                        className="bg-gradient-secondary h-3 rounded-full transition-all duration-1000 ease-out shadow-[0_0_8px_rgba(255,168,0,0.8)]"
                        style={{ width: `${Math.min(completionPct, 100)}%` }}
                    />
                </div>
                <div className="flex justify-between text-[10px] uppercase font-bold text-brand-muted relative z-10">
                    <span>0%</span>
                    <span className={cn(completionPct === 100 && "text-brand-success font-black")}>{completionPct}%</span>
                </div>
            </div>

            {/* Grid Stats */}
            <div className="grid grid-cols-2 gap-4">

                {/* Readiness Score */}
                <div className="glass-panel p-5 flex flex-col justify-between col-span-2 shadow-[0_0_15px_rgba(65,209,255,0.05)] relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-primary opacity-10 blur-3xl -ml-10 -mt-10 rounded-full pointer-events-none"></div>
                    <div className="flex justify-between items-center relative z-10">
                        <h3 className="text-brand-muted text-[10px] uppercase tracking-widest font-bold flex items-center gap-1">
                            <Zap size={12} className="text-brand-primary" /> Readiness Score
                        </h3>
                        <span className="text-[10px] font-bold text-brand-muted uppercase tracking-widest">0-100</span>
                    </div>
                    <div className="mt-4 flex items-center justify-between relative z-10">
                        <div className="flex items-baseline gap-2">
                            <span className={cn(
                                "text-5xl font-black font-mono",
                                readinessScore >= 80 ? "text-brand-success drop-shadow-[0_0_10px_rgba(89,191,150,0.6)]" :
                                    readinessScore >= 50 ? "text-brand-secondary drop-shadow-[0_0_10px_rgba(255,234,131,0.6)]" :
                                        "text-brand-danger drop-shadow-[0_0_10px_rgba(255,92,122,0.6)]"
                            )}>
                                {readinessScore}
                            </span>
                            <span className="text-xs uppercase font-bold text-brand-muted track-widest">
                                {readinessScore >= 80 ? 'Peak' : readinessScore >= 50 ? 'Steady' : 'Recover'}
                            </span>
                        </div>
                    </div>
                </div>

                {/* Plan Status vs Timeline */}
                <div className="glass-panel p-5 flex flex-col justify-between col-span-2 shadow-[0_0_15px_rgba(189,52,254,0.05)]">
                    <div className="flex justify-between items-center mb-3">
                        <h3 className="text-brand-muted text-[10px] uppercase tracking-widest font-bold flex items-center gap-1">
                            <ActivityIcon size={12} className="text-brand-primary" /> Plan vs Timeline
                        </h3>
                        <div className={cn(
                            "text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded-md border",
                            statusInfo.behindCount === 0 ? "bg-brand-success/20 text-brand-success border-brand-success/30" :
                                statusInfo.behindCount <= 2 ? "bg-brand-secondary/20 text-brand-secondary border-brand-secondary/30" :
                                    "bg-brand-danger/20 text-brand-danger border-brand-danger/30 shadow-[0_0_8px_rgba(255,92,122,0.4)]"
                        )}>
                            {statusInfo.status}
                        </div>
                    </div>

                    <div className="space-y-3">
                        {/* Timeline Progress */}
                        <div>
                            <div className="flex justify-between text-[10px] uppercase font-bold text-brand-muted mb-1">
                                <span>Time Elapsed</span>
                                <span className="text-white">{statusInfo.planProgress}%</span>
                            </div>
                            <div className="w-full bg-brand-bg/50 rounded-full h-1.5 overflow-hidden">
                                <div className="bg-brand-muted h-1.5 rounded-full" style={{ width: `${statusInfo.planProgress}%` }} />
                            </div>
                        </div>
                        {/* Session Progress */}
                        <div>
                            <div className="flex justify-between text-[10px] uppercase font-bold text-brand-muted mb-1">
                                <span>Sessions Done</span>
                                <span className="text-brand-primary drop-shadow-[0_0_5px_rgba(65,209,255,0.6)]">{statusInfo.sessionProgress}%</span>
                            </div>
                            <div className="w-full bg-brand-bg/50 rounded-full h-1.5 overflow-hidden">
                                <div className="bg-gradient-primary h-1.5 rounded-full shadow-[0_0_8px_rgba(65,209,255,0.8)]" style={{ width: `${statusInfo.sessionProgress}%` }} />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Legacy Stats -> Converted to smaller cards */}
                <div className="glass-panel p-4 flex flex-col justify-between">
                    <h3 className="text-brand-muted text-[10px] uppercase tracking-widest font-bold">Total Sessions</h3>
                    <span className="text-3xl font-black font-mono mt-1 text-white">{totalSessions}</span>
                </div>

                {/* Weight */}
                <div className="glass-panel p-4 flex flex-col justify-between">
                    <h3 className="text-brand-muted text-[10px] uppercase tracking-widest font-bold">Weight</h3>
                    <div className="flex items-end justify-between mt-2">
                        <span className="text-2xl font-black font-mono">
                            {currentWeight !== undefined ? `${Number(currentWeight).toFixed(1)}` : '--'}
                            <span className="text-[10px] font-bold text-brand-muted ml-0.5 uppercase">kg</span>
                        </span>
                        {weightDelta !== null && (
                            <div className={cn(
                                "flex items-center text-[10px] font-bold px-2 py-1 rounded-full",
                                weightDelta < 0 ? "bg-brand-success/20 text-brand-success" : weightDelta > 0 ? "bg-brand-danger/20 text-brand-danger shadow-[0_0_8px_rgba(255,92,122,0.4)]" : "bg-brand-panel-2 text-brand-muted"
                            )}>
                                {weightDelta < 0 ? <TrendingDown size={12} className="mr-1" /> : weightDelta > 0 ? <TrendingUp size={12} className="mr-1" /> : <Minus size={12} className="mr-1" />}
                                {Math.abs(weightDelta).toFixed(1)}
                            </div>
                        )}
                    </div>
                </div>

                {/* Fatigue Tracker */}
                <div className="glass-panel p-4 flex flex-col justify-between col-span-2">
                    <div className="flex justify-between items-center">
                        <h3 className="text-brand-muted text-[10px] uppercase tracking-widest font-bold">Latest Fatigue</h3>
                        <span className="text-[10px] font-bold text-brand-muted uppercase tracking-widest bg-brand-bg/50 px-2 py-1 rounded-md border border-brand-border/30">Scale: 1-10</span>
                    </div>
                    <div className="mt-3 flex items-center">
                        <span className={cn(
                            "text-3xl font-black font-mono",
                            latestFatigue !== undefined && Number(latestFatigue) >= 8 ? "text-brand-danger drop-shadow-[0_0_8px_rgba(255,92,122,0.6)]" :
                                latestFatigue !== undefined && Number(latestFatigue) >= 5 ? "text-brand-warning drop-shadow-[0_0_8px_rgba(255,168,0,0.6)]" :
                                    "text-brand-success drop-shadow-[0_0_8px_rgba(89,191,150,0.6)]"
                        )}>
                            {latestFatigue ?? '--'}
                        </span>
                        {latestFatigue !== undefined && (
                            <div className="ml-4 flex-1 h-3 bg-brand-bg/50 rounded-full overflow-hidden border border-brand-border/50">
                                <div
                                    className={cn(
                                        "h-full rounded-full transition-all",
                                        Number(latestFatigue) >= 8 ? "bg-brand-danger shadow-[0_0_8px_rgba(255,92,122,0.8)]" : Number(latestFatigue) >= 5 ? "bg-gradient-secondary shadow-[0_0_8px_rgba(255,168,0,0.8)]" : "bg-brand-success"
                                    )}
                                    style={{ width: `${(Number(latestFatigue) / 10) * 100}%` }}
                                />
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
