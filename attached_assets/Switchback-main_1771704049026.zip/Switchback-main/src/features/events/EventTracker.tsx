import { useState, useEffect } from 'react';
import type { AppData, GoalEvent } from '../../types';
import { Settings, ExternalLink, Mountain, MapPin, Map, Check, Flame, BatteryCharging } from 'lucide-react';
import { cn } from '../../lib/utils';

interface Props {
    appData: AppData;
    setAppData: (data: AppData) => void;
}

export function EventTracker({ appData, setAppData }: Props) {
    const [isEditing, setIsEditing] = useState(false);
    const [goal, setGoal] = useState<GoalEvent | undefined>(appData.goal);

    // Local form state
    const [name, setName] = useState(goal?.name || '');
    const [date, setDate] = useState(goal?.startDate || '');
    const [distance, setDistance] = useState(goal?.distanceKm?.toString() || '');
    const [elevation, setElevation] = useState(goal?.elevationMeters?.toString() || '');
    const [location, setLocation] = useState(goal?.location || '');
    const [link, setLink] = useState(goal?.link || '');

    const [{ days, hours, mins }, setTimeLeft] = useState(() => calculateTimeLeft(goal?.startDate));

    // Calculate smart phases
    const peakWeekStarts = days - 14;
    const taperBegins = days - 7;
    let smartLabel = null;
    let SmartIcon = null;

    if (days > 14) {
        smartLabel = `Peak Week Starts In: ${peakWeekStarts} Days`;
        SmartIcon = Flame;
    } else if (days > 7 && days <= 14) {
        smartLabel = `Taper Begins In: ${taperBegins} Days`;
        SmartIcon = BatteryCharging;
    } else if (days > 0 && days <= 7) {
        smartLabel = "Race Week! Tapering...";
        SmartIcon = BatteryCharging;
    } else if (days === 0 && (hours > 0 || mins > 0)) {
        smartLabel = "Race Day!";
        SmartIcon = Flame;
    }

    useEffect(() => {
        const timer = setInterval(() => {
            setTimeLeft(calculateTimeLeft(goal?.startDate));
        }, 60000); // update every minute
        return () => clearInterval(timer);
    }, [goal?.startDate]);

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        const updatedGoal: GoalEvent = {
            ...goal,
            id: goal?.id || `evt-${Date.now()}`,
            name,
            startDate: date,
            distanceKm: distance ? parseFloat(distance) : undefined,
            elevationMeters: elevation ? parseInt(elevation, 10) : undefined,
            location: location || undefined,
            link: link || undefined,
            createdAt: goal?.createdAt || new Date().toISOString()
        };

        setGoal(updatedGoal);
        setAppData({ ...appData, goal: updatedGoal });
        setIsEditing(false);
    };

    return (
        <div className="p-4 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex justify-between items-center mb-2">
                <h2 className="text-2xl font-bold">Goal Event</h2>
                <button
                    onClick={() => setIsEditing(!isEditing)}
                    className={cn(
                        "p-2 rounded-full transition-all",
                        isEditing
                            ? "bg-brand-panel-2 text-brand-text hover:bg-brand-border"
                            : "bg-gradient-primary text-brand-bg shadow-[0_0_10px_rgba(65,209,255,0.4)]"
                    )}
                >
                    <Settings size={20} />
                </button>
            </div>

            {!isEditing && goal && (
                <>
                    {/* Hero Countdown Card */}
                    <div className="glass-panel relative overflow-hidden p-6 mb-8 mt-4 border border-brand-primary/30 shadow-[0_0_20px_rgba(65,209,255,0.1)]">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-primary opacity-20 blur-3xl rounded-full -mr-10 -mt-10 pointer-events-none"></div>
                        <div className="absolute bottom-0 left-0 w-40 h-40 bg-gradient-secondary opacity-10 blur-3xl rounded-full -ml-10 -mb-10 pointer-events-none"></div>

                        <h3 className="text-2xl font-bold text-center tracking-tight text-white mb-2">{goal.name}</h3>
                        {goal.location && (
                            <p className="text-center text-brand-primary font-medium text-sm mb-6 flex items-center justify-center gap-1">
                                <MapPin size={14} /> {goal.location}
                            </p>
                        )}

                        <div className="flex justify-center gap-3 mt-4">
                            <CountdownBox value={days} label="Days" />
                            <div className="text-2xl font-bold text-brand-muted self-center mb-5">:</div>
                            <CountdownBox value={hours} label="Hours" />
                            <div className="text-2xl font-bold text-brand-muted self-center mb-5">:</div>
                            <CountdownBox value={mins} label="Mins" />
                        </div>

                        <p className="text-center text-brand-muted text-[10px] mt-6 font-mono tracking-widest uppercase mb-4">
                            {new Date(goal.startDate).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                        </p>

                        {smartLabel && SmartIcon && (
                            <div className="flex items-center justify-center gap-2 mt-2 py-2 px-4 rounded-full bg-brand-panel-2 border border-brand-border/50 text-xs font-bold font-mono text-brand-text shadow-inner w-max mx-auto">
                                <SmartIcon size={14} className={days > 14 ? "text-brand-warning" : "text-brand-success"} />
                                {smartLabel}
                            </div>
                        )}
                    </div>

                    {/* Stats Grid */}
                    <h4 className="text-xs font-bold text-brand-muted uppercase tracking-widest pl-1 mb-3">Event Intel</h4>
                    <div className="grid grid-cols-2 gap-3 mb-6">
                        <StatCard icon={<Map size={18} className="text-brand-primary" />} label="Distance" value={goal.distanceKm ? `${goal.distanceKm}km` : 'TBD'} />
                        <StatCard icon={<Mountain size={18} className="text-brand-secondary" />} label="Elevation" value={goal.elevationMeters ? `${goal.elevationMeters}m` : 'TBD'} />
                    </div>

                    {/* Action Links */}
                    {goal.link && (
                        <a
                            href={goal.link}
                            target="_blank"
                            rel="noreferrer"
                            className="flex items-center justify-center gap-2 w-full py-4 rounded-xl glass-panel text-brand-text font-bold uppercase tracking-wider hover:bg-brand-panel-2 transition-colors border border-brand-border"
                        >
                            Event Website <ExternalLink size={18} className="text-brand-primary" />
                        </a>
                    )}
                </>
            )}

            {(!goal || isEditing) && (
                <form onSubmit={handleSave} className="glass-panel p-5 relative overflow-hidden shadow-[0_0_20px_rgba(189,52,254,0.1)]">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-primary opacity-20 blur-3xl rounded-full -mr-10 -mt-10 pointer-events-none"></div>

                    <h3 className="text-lg font-bold mb-4">Configure Target Event</h3>

                    <div className="space-y-4">
                        <div>
                            <label className="text-xs text-brand-muted font-medium block mb-1">Event Name</label>
                            <input type="text" value={name} onChange={e => setName(e.target.value)} required className="w-full bg-brand-bg text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm focus:border-brand-primary focus:ring-1 focus:ring-brand-primary outline-none" placeholder="e.g. GravDuro 2026" />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-xs text-brand-muted font-medium block mb-1">Date</label>
                                <input type="date" value={date} onChange={e => setDate(e.target.value)} required className="w-full bg-brand-bg text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm focus:border-brand-primary focus:ring-1 focus:ring-brand-primary outline-none" />
                            </div>
                            <div>
                                <label className="text-xs text-brand-muted font-medium block mb-1">Location</label>
                                <input type="text" value={location} onChange={e => setLocation(e.target.value)} className="w-full bg-brand-bg text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm focus:border-brand-primary focus:ring-1 focus:ring-brand-primary outline-none" placeholder="e.g. Grabouw" />
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-xs text-brand-muted font-medium block mb-1">Distance (km)</label>
                                <input type="number" value={distance} onChange={e => setDistance(e.target.value)} className="w-full bg-brand-bg text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm focus:border-brand-primary focus:ring-1 focus:ring-brand-primary outline-none" placeholder="e.g. 86" />
                            </div>
                            <div>
                                <label className="text-xs text-brand-muted font-medium block mb-1">Elevation (m)</label>
                                <input type="number" value={elevation} onChange={e => setElevation(e.target.value)} className="w-full bg-brand-bg text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm focus:border-brand-primary focus:ring-1 focus:ring-brand-primary outline-none" placeholder="e.g. 1200" />
                            </div>
                        </div>

                        <div>
                            <label className="text-xs text-brand-muted font-medium block mb-1">Website Link</label>
                            <input type="url" value={link} onChange={e => setLink(e.target.value)} className="w-full bg-brand-bg text-brand-text border border-brand-border rounded-lg px-3 py-2 text-sm focus:border-brand-primary focus:ring-1 focus:ring-brand-primary outline-none" placeholder="https://..." />
                        </div>

                        <button type="submit" className="w-full py-3 mt-2 bg-gradient-primary rounded-xl font-bold text-brand-bg hover:opacity-90 flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(65,209,255,0.3)]">
                            <Check size={20} /> Save Target Event
                        </button>
                    </div>
                </form>
            )}
        </div>
    );
}

function CountdownBox({ value, label }: { value: string | number, label: string }) {
    return (
        <div className="flex flex-col items-center justify-center glass-panel w-20 h-24 border-brand-border/50 shadow-inner">
            <span className="text-3xl font-bold font-mono text-gradient-primary mb-1">{value}</span>
            <span className="text-[10px] uppercase font-bold tracking-widest text-brand-muted">{label}</span>
        </div>
    );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode, label: string, value: string | number }) {
    return (
        <div className="glass-panel p-4 flex flex-col justify-center items-start border-brand-border/50">
            <div className="flex items-center gap-2 text-brand-muted mb-2">
                {icon} <span className="text-[10px] uppercase font-bold tracking-widest">{label}</span>
            </div>
            <span className="text-xl font-bold font-mono pl-1">{value}</span>
        </div>
    );
}

// Utility to calculate countdown metrics
function calculateTimeLeft(targetDate?: string) {
    if (!targetDate) return { days: 0, hours: 0, mins: 0 };

    const difference = +new Date(targetDate) - +new Date();

    if (difference > 0) {
        return {
            days: Math.floor(difference / (1000 * 60 * 60 * 24)),
            hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
            mins: Math.floor((difference / 1000 / 60) % 60)
        };
    }

    return { days: 0, hours: 0, mins: 0 };
}
