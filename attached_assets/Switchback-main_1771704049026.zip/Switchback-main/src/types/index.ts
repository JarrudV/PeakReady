// src/types/index.ts
export type SessionType = "Ride" | "Long Ride" | "Strength" | "Rest";

export type Session = {
    id: string;
    week: number;                 // 1–12
    day: "Tue" | "Thu" | "Sat" | "Sun";
    type: SessionType;
    description: string;
    minutes: number;
    zone?: string;                // "Z2" etc
    elevation?: string;           // "Flat" | "Mixed" | "Climb"
    strength: boolean;
    completed: boolean;
    rpe?: number;
    notes?: string;
    scheduledDate?: string;       // ISO date, anchored to goal
    completedAt?: string;         // ISO datetime
};

export type Metric = {
    date: string;                 // ISO date
    weightKg?: number;
    restingHr?: number;
    rideMinutes?: number;
    longRideKm?: number;
    fatigue?: number;             // 1–10
    notes?: string;
};

export type ServiceItem = {
    id: string;
    date?: string;                // ISO date
    item: string;
    shop?: string;
    cost?: number;
    status: "Planned" | "In Progress" | "Done";
    notes?: string;
};

export type GoalEvent = {
    id: string;
    name: string;
    link?: string;
    startDate: string;            // ISO date
    location?: string;
    distanceKm?: number;
    elevationMeters?: number;
    notes?: string;
    createdAt: string;            // ISO datetime
    lastSyncedAt?: string;        // ISO datetime
};

export interface StravaAuth {
    clientId: string;
    clientSecret: string;
    refreshToken: string;
    accessToken?: string;
    expiresAt?: number;
}

export interface AppData {
    sessions: Session[];
    metrics: Metric[];
    serviceItems: ServiceItem[];
    activeWeek: number;
    goal?: GoalEvent;
    strava?: StravaAuth;
}
